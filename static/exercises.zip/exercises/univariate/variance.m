function s2 = variance(x)
  %  variance  Calculate variance
  % 
  %  Arguments
  %  ---------
  %  x    1D array of sample input data
  %
  %  Returns
  %  -------
  %  s2  double, the variance of x
  %
  
  % REPLACE FROM HERE
  s2 = var(x);
  % TO HERE 
end